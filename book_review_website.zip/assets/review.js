
const book = JSON.parse(localStorage.getItem('selectedBook'));
document.getElementById('book-title').textContent = book.title;
document.getElementById('book-review').innerHTML = `<p>${book.review}</p>`;
