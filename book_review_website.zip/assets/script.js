
fetch('books.json')
  .then(response => response.json())
  .then(data => {
    const list = document.getElementById('book-list');
    data.books.forEach(book => {
      const item = document.createElement('div');
      item.className = 'book-item';
      item.textContent = book.title;
      item.onclick = () => {
        localStorage.setItem('selectedBook', JSON.stringify(book));
        window.location.href = 'review.html';
      };
      list.appendChild(item);
    });
  });
